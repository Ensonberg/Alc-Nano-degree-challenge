package com.edirinmuoghogmail.testquiz;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Checkable;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button bt2 =(Button) findViewById(R.id.submit);
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int score=0;
                if (((RadioButton)findViewById(R.id.ans1)).isChecked()) {score++;}
                if (((RadioButton)findViewById(R.id.ans4)).isChecked()) {score++;}
                if (((RadioButton)findViewById(R.id.ans2)).isChecked()) {score++;}
                if (((RadioButton)findViewById(R.id.ai)).isChecked()) {score++;}
                if (((RadioButton)findViewById(R.id.java)).isChecked()) {score++;}
                if (((CheckBox)findViewById(R.id.q8)).isChecked()) {score++;}
                if (((RadioButton) findViewById(R.id.ans3)).isChecked()) {score++; }
                if (((CheckBox)findViewById(R.id.b3)).isChecked()) {score++;}
                if (((CheckBox)findViewById(R.id.q9)).isChecked()) {score++;}
                if (((CheckBox)findViewById(R.id.b1)).isChecked()) {score++;}






                displayScore(score);

            }
        });



    }
    public  void  displayScore(int score){

        EditText editText=(EditText)findViewById(R.id.text);
        String name=editText.getText().toString();
        String message = name+"\n You scored " + score;
        message += " out of 10";
        message += "\nWell done!";
        Toast toast = Toast.makeText(this, message, Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER, 0 , 0);

        toast.show();


    }
}
